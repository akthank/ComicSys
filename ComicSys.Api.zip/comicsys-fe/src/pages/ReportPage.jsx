import { useState } from "react";
import { Card, DatePicker, Button, Table, Typography, message } from "antd";
import dayjs from "dayjs";
import { reportRents } from "../api.js";

export default function ReportPage(){
  const [range, setRange] = useState([dayjs().startOf("month"), dayjs().endOf("month")]);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);

  const run = async ()=>{
    if(!range?.[0] || !range?.[1]) return message.warning("Pick a date range");
    setLoading(true);
    try{
      const { data } = await reportRents(range[0].format("YYYY-MM-DD"), range[1].format("YYYY-MM-DD"));
      setRows(Array.isArray(data) ? data : []);
    } finally{ setLoading(false); }
  };

  const columns = [
    { title:"#", render:(_, __, i)=>i+1, width:60 },
    { title:"Book name", dataIndex:"bookName" },
    { title:"Rental date", dataIndex:"rentalDate", render:v=>dayjs(v).format("DD/MM/YYYY"), width:140 },
    { title:"Return date", dataIndex:"returnDate", render:v=>dayjs(v).format("DD/MM/YYYY"), width:140 },
    { title:"Customer", dataIndex:"customerName" },
    { title:"Qty", dataIndex:"quantity", align:"right", width:100 },
  ];

  return (
    <>
      <div className="page-header">
        <Typography.Title level={3} style={{margin:0}}>Report — Rents</Typography.Title>
        <div/>
      </div>

      <Card className="card" style={{ marginBottom:12 }}>
        <DatePicker.RangePicker value={range} onChange={(v)=>setRange(v)} />
        <Button type="primary" onClick={run} style={{ marginLeft:8 }} loading={loading}>Run</Button>
      </Card>

      <div className="table-card">
        <Table rowKey={(_,i)=>i} columns={columns} dataSource={rows} loading={loading}/>
      </div>
    </>
  );
}
