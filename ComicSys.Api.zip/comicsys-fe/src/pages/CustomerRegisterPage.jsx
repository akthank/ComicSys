import { useState } from "react";
import { Card, Form, Input, DatePicker, Button, Typography, message } from "antd";
import dayjs from "dayjs";
import { registerCustomer } from "../api.js";

export default function CustomerRegisterPage(){
  const [submitting, setSubmitting] = useState(false);
  const [form] = Form.useForm();

  const onSubmit = async ()=>{
    const v = await form.validateFields();
    setSubmitting(true);
    try{
      await registerCustomer({
        fullName: v.fullName,
        phone: v.phone,
        registerDate: dayjs(v.registerDate).toISOString(),
      });
      message.success("Registered successfully!");
      form.resetFields();
    } finally{ setSubmitting(false); }
  };

  return (
    <>
      <div className="page-header">
        <Typography.Title level={3} style={{margin:0}}>Register Customer</Typography.Title>
      </div>

      <Card className="card">
        <Form form={form} layout="vertical" initialValues={{ registerDate: dayjs() }}>
          <Form.Item label="Full name" name="fullName" rules={[{required:true}]}>
            <Input placeholder="Nguyen Van A"/>
          </Form.Item>
          <Form.Item label="Phone" name="phone" rules={[{required:true}]}>
            <Input placeholder="090..."/>
          </Form.Item>
          <Form.Item label="Register date" name="registerDate" rules={[{required:true}]}>
            <DatePicker style={{width:"100%"}}/>
          </Form.Item>
          <Button type="primary" onClick={onSubmit} loading={submitting}>Submit</Button>
        </Form>
      </Card>
    </>
  );
}
