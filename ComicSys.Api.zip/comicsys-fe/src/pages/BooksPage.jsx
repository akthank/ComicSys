import { useEffect, useState } from "react";
import { Button, Table, Space, Modal, Form, Input, InputNumber, Popconfirm, Typography, message } from "antd";
import { PlusOutlined, EditOutlined, DeleteOutlined } from "@ant-design/icons";
import { listBooks, createBook, updateBook, deleteBook } from "../api.js";

export default function BooksPage(){
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form] = Form.useForm();

  const fetchData = async ()=>{
    setLoading(true);
    try{
      const res = await listBooks();
      const data = Array.isArray(res?.data) ? res.data : [];
      setRows(data);
    } catch(message){
      message.error("Failed to load books");
      setRows([]);
    } finally{ setLoading(false); }
  };

  useEffect(()=>{ fetchData(); },[]);

  const onCreate = ()=>{
    setEditing(null);
    form.resetFields();
    setOpen(true);
  };

  const onEdit = (record)=>{
    setEditing(record);
    form.setFieldsValue(record);
    setOpen(true);
  };

  const onSubmit = async ()=>{
    const values = await form.validateFields();
    if(editing){
      await updateBook(editing.id, values);
      message.success("Updated");
    }else{
      await createBook(values);
      message.success("Created");
    }
    setOpen(false);
    fetchData();
  };

  const onDelete = async (id)=>{
    await deleteBook(id);
    message.success("Deleted");
    fetchData();
  };

  const columns = [
    { title:"#", dataIndex:"id", width:70 },
    { title:"Name", dataIndex:"name" },
    { title:"Author", dataIndex:"author" },
    { title:"Price/Day", dataIndex:"pricePerDay", align:"right", width:120 },
    { title:"In Stock", dataIndex:"quantityInStock", align:"right", width:120 },
    {
      title:"Actions",
      key:"actions",
      align:"center",
      width:150,
      render:(_,record)=>(
        <Space>
          <Button icon={<EditOutlined/>} onClick={()=>onEdit(record)}>Edit</Button>
          <Popconfirm title="Delete this book?" onConfirm={()=>onDelete(record.id)}>
            <Button danger icon={<DeleteOutlined/>}/>
          </Popconfirm>
        </Space>
      )
    },
  ];

  return (
    <>
      <div className="page-header">
        <Typography.Title level={3} style={{margin:0}}>Books</Typography.Title>
        <Button type="primary" icon={<PlusOutlined/>} onClick={onCreate}>New Book</Button>
      </div>

      <div className="table-card">
        <Table rowKey="id" columns={columns} dataSource={rows} loading={loading} pagination={{ pageSize:8 }}/>
      </div>

      <Modal
        title={editing ? "Edit Book" : "New Book"}
        open={open}
        onCancel={()=>setOpen(false)}
        onOk={onSubmit}
        okText={editing ? "Save" : "Create"}
      >
        <Form form={form} layout="vertical">
          <Form.Item label="Name" name="name" rules={[{required:true}]}>
            <Input placeholder="Name"/>
          </Form.Item>
          <Form.Item label="Author" name="author">
            <Input placeholder="Author"/>
          </Form.Item>
          <Form.Item label="Price per day" name="pricePerDay" initialValue={1} rules={[{required:true}]}>
            <InputNumber min={0} style={{width:"100%"}}/>
          </Form.Item>
          <Form.Item label="Quantity in stock" name="quantityInStock" initialValue={0} rules={[{required:true}]}>
            <InputNumber min={0} style={{width:"100%"}}/>
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
}
