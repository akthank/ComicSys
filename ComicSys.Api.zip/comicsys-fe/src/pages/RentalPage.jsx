import { useEffect, useState } from "react";
import { Card, Form, Select, DatePicker, InputNumber, Button, Space, Table, Typography, message } from "antd";
import { PlusOutlined, DeleteOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import { listBooks, listCustomers, createRental } from "../api.js";

export default function RentalPage(){
  const [customers, setCustomers] = useState([]);
  const [books, setBooks] = useState([]);
  const [items, setItems] = useState([{ comicBookId: null, quantity: 1, pricePerDay: 1 }]);
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();

  useEffect(()=>{
    (async ()=>{
      const [cs, bs] = await Promise.all([listCustomers(), listBooks()]);
      setCustomers(cs.data || []);
      setBooks(bs.data || []);
    })();
  },[]);

  const addItem = ()=> setItems([...items, { comicBookId:null, quantity:1, pricePerDay:1 }]);
  const removeItem = (idx)=> setItems(items.filter((_,i)=>i!==idx));
  const updateItem = (idx, patch)=>{ const cp=[...items]; cp[idx]={...cp[idx], ...patch}; setItems(cp); };

  const bookOptions = books.map(b=>({ label:b.name, value:b.id }));
  const customerOptions = customers.map(c=>({ label:c.fullName, value:c.id }));

  const columns = [
    {
      title:"Book",
      render:(_,r,i)=>(
        <Select
          style={{width:260}}
          options={[{label:"Select book", value:null, disabled:true}, ...bookOptions]}
          value={r.comicBookId}
          onChange={(v)=>{
            const found = books.find(b=>b.id===v);
            updateItem(i,{ comicBookId:v, pricePerDay: found ? found.pricePerDay : r.pricePerDay });
          }}
        />
      )
    },
    {
      title:"Quantity",
      dataIndex:"quantity",
      align:"right",
      width:140,
      render:(v,_,i)=><InputNumber min={1} value={v} onChange={(x)=>updateItem(i,{quantity:x})}/>
    },
    {
      title:"Price/Day",
      dataIndex:"pricePerDay",
      align:"right",
      width:160,
      render:(v,_,i)=><InputNumber min={0} value={v} onChange={(x)=>updateItem(i,{pricePerDay:x})}/>
    },
    {
      title:"",
      align:"center",
      width:80,
      render:(_, __, i)=>(
        <Button danger icon={<DeleteOutlined/>} onClick={()=>removeItem(i)}/>
      )
    }
  ];

  const onSubmit = async ()=>{
    try{
      const v = await form.validateFields();
      const payload = {
        customerId: v.customerId,
        rentalDate: dayjs(v.rentalDate).toISOString(),
        returnDate: dayjs(v.returnDate).toISOString(),
        items: items.filter(it=>it.comicBookId).map(it=>({
          comicBookId: it.comicBookId,
          quantity: it.quantity,
          pricePerDay: it.pricePerDay
        }))
      };
      if (!payload.items.length) return message.warning("Please add at least one item.");
      setLoading(true);
      await createRental(payload);
      message.success("Rental created!");
      setItems([{ comicBookId:null, quantity:1, pricePerDay:1 }]);
    } finally{ setLoading(false); }
  };

  return (
    <>
      <div className="page-header">
        <Typography.Title level={3} style={{margin:0}}>Rent a Book</Typography.Title>
        <Button icon={<PlusOutlined/>} onClick={addItem}>Add item</Button>
      </div>

      <Card className="card" style={{ marginBottom:12 }}>
        <Form form={form} layout="inline" initialValues={{
          rentalDate: dayjs(),
          returnDate: dayjs().add(7, "day"),
        }}>
          <Form.Item label="Customer" name="customerId" rules={[{required:true}]}>
            <Select style={{width:280}} options={customerOptions} placeholder="Select customer"/>
          </Form.Item>
          <Form.Item label="Rental date" name="rentalDate" rules={[{required:true}]}>
            <DatePicker />
          </Form.Item>
          <Form.Item label="Return date" name="returnDate" rules={[{required:true}]}>
            <DatePicker />
          </Form.Item>
          <Form.Item>
            <Space>
              <Button type="primary" onClick={onSubmit} loading={loading}>Create Rental</Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>

      <div className="table-card">
        <Table columns={columns} dataSource={items} rowKey={(_,i)=>i} pagination={false}/>
      </div>
    </>
  );
}
