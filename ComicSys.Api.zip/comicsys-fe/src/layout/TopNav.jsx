import { Layout, Typography } from "antd";
const { Header } = Layout;

export default function TopNav(){
  return (
    <Header style={{ background:"#fff", padding:"0 16px", borderBottom:"1px solid #f0f0f0" }}>
      <Typography.Title level={4} className="header-title" style={{ margin:0 }}>
        ComicSys • Ant Design
      </Typography.Title>
    </Header>
  );
}
