import { Layout, Menu } from "antd";
import {
  BookOutlined,
  UserAddOutlined,
  ShoppingCartOutlined,
  BarChartOutlined,
} from "@ant-design/icons";
import { Link, useLocation } from "react-router-dom";

const { Sider } = Layout;

export default function SideNav(){
  const { pathname } = useLocation();
  const items = [
    { key:"/books", icon:<BookOutlined/>, label:<Link to="/books">Books (CRUD)</Link> },
    { key:"/customers/register", icon:<UserAddOutlined/>, label:<Link to="/customers/register">Register Customer</Link> },
    { key:"/rentals/new", icon:<ShoppingCartOutlined/>, label:<Link to="/rentals/new">Rent a Book</Link> },
    { key:"/reports/rents", icon:<BarChartOutlined/>, label:<Link to="/reports/rents">Report: Rents</Link> },
  ];
  return (
    <Sider breakpoint="lg" collapsedWidth="0" width={240} style={{ background:"#fff", borderRight:"1px solid #f0f0f0" }}>
      <div style={{ height:56, display:"flex", alignItems:"center", padding:"0 16px", fontWeight:700 }}>ComicSys</div>
      <Menu mode="inline" selectedKeys={[pathname]} items={items}/>
    </Sider>
  );
}
