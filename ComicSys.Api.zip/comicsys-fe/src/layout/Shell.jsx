import { Layout } from "antd";
import TopNav from "./TopNav.jsx";
import SideNav from "./SideNav.jsx";
import "../styles.css";

const { Content } = Layout;

export default function Shell({ children }){
  return (
    <Layout className="app-shell">
      <SideNav/>
      <Layout>
        <TopNav/>
        <Content style={{ margin:16 }}>
          {children}
        </Content>
      </Layout>
    </Layout>
  );
}
