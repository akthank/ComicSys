import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Shell from "./layout/Shell.jsx";
import BooksPage from "./pages/BooksPage.jsx";
import CustomerRegisterPage from "./pages/CustomerRegisterPage.jsx";
import RentalPage from "./pages/RentalPage.jsx";
import ReportPage from "./pages/ReportPage.jsx";
import NotFound from "./pages/NotFound.jsx";

export default function App(){
  return (
    <BrowserRouter>
      <Shell>
        <Routes>
          <Route path="/" element={<Navigate to="/books" replace/>} />
          <Route path="/books" element={<BooksPage/>} />
          <Route path="/customers/register" element={<CustomerRegisterPage/>} />
          <Route path="/rentals/new" element={<RentalPage/>} />
          <Route path="/reports/rents" element={<ReportPage/>} />
          <Route path="*" element={<NotFound/>} />
        </Routes>
      </Shell>
    </BrowserRouter>
  );
}
