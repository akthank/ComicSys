import axios from "axios";

export const API_BASE = "http://localhost:5070/api"; // đổi theo port BE của bạn

const api = axios.create({ baseURL: API_BASE, withCredentials: false });

// Books
export const listBooks   = () => api.get("/books");
export const getBook     = (id) => api.get(`/books/${id}`);
export const createBook  = (data) => api.post("/books", data);
export const updateBook  = (id, data) => api.put(`/books/${id}`, data);
export const deleteBook  = (id) => api.delete(`/books/${id}`);

// Customers
export const registerCustomer = (data) => api.post("/customers", data);
export const listCustomers    = () => api.get("/customers");

// Rentals
export const createRental = (data) => api.post("/rentals", data);

// Reports
export const reportRents = (start, end) => api.get("/reports/rents", { params: { start, end } });
