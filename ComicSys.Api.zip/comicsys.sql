-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: mysql
-- Thời gian đã tạo: Th10 03, 2025 lúc 12:14 PM
-- Phiên bản máy phục vụ: 5.7.44
-- Phiên bản PHP: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `comicsys`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `comic_books`
--

CREATE TABLE `comic_books` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price_per_day` decimal(10,2) NOT NULL DEFAULT '0.00',
  `quantity_in_stock` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `comic_books`
--

INSERT INTO `comic_books` (`id`, `name`, `author`, `price_per_day`, `quantity_in_stock`, `created_at`, `updated_at`) VALUES
(1, 'One Piece 11', 'Oda', 2.00, 9, '2025-10-03 11:36:37.331395', '2025-10-03 11:50:59.400293'),
(2, 'Naruto 1', 'Kishimoto', 1.50, 7, '2025-10-03 11:36:37.331395', '2025-10-03 11:50:40.483194'),
(3, 'Doraemon 1', 'Fujiko F.', 1.20, 12, '2025-10-03 11:36:37.331395', '2025-10-03 11:36:37.331395'),
(5, 'Life Skills for Tweens', 'Ferne Bowe', 10.00, 100, '2025-10-03 12:10:43.335851', '2025-10-03 12:10:43.335851');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `register_date` datetime(6) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `customers`
--

INSERT INTO `customers` (`id`, `full_name`, `phone`, `register_date`, `created_at`, `updated_at`) VALUES
(1, 'Nguyen Van A', '090000001', '2025-09-28 11:36:37.413095', '2025-10-03 11:36:37.413095', '2025-10-03 11:36:37.413095'),
(2, 'Tran Thi B', '090000002', '2025-10-03 11:36:37.413095', '2025-10-03 11:36:37.413095', '2025-10-03 11:36:37.413095'),
(4, 'Ngô Tất Tố', '012345678', '2025-10-02 17:00:00.000000', '2025-10-03 11:50:20.802904', '2025-10-03 11:50:20.802904');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rentals`
--

CREATE TABLE `rentals` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `rental_date` datetime(6) NOT NULL,
  `return_date` datetime(6) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rentals`
--

INSERT INTO `rentals` (`id`, `customer_id`, `rental_date`, `return_date`, `created_at`, `updated_at`) VALUES
(1, 4, '2025-10-02 17:00:00.000000', '2025-10-09 17:00:00.000000', '2025-10-03 11:50:40.483566', '2025-10-03 11:50:40.483566');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `rental_items`
--

CREATE TABLE `rental_items` (
  `id` int(11) NOT NULL,
  `rental_id` int(11) NOT NULL,
  `comic_book_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price_per_day` decimal(10,2) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `rental_items`
--

INSERT INTO `rental_items` (`id`, `rental_id`, `comic_book_id`, `quantity`, `price_per_day`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 1, 1.50, '2025-10-03 11:50:40.500026', '2025-10-03 11:50:40.500026'),
(2, 1, 1, 1, 2.00, '2025-10-03 11:50:40.500786', '2025-10-03 11:50:40.500786');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `comic_books`
--
ALTER TABLE `comic_books`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ix_rentals_customer_id` (`customer_id`);

--
-- Chỉ mục cho bảng `rental_items`
--
ALTER TABLE `rental_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ix_rental_items_rental_id` (`rental_id`),
  ADD KEY `ix_rental_items_comic_book_id` (`comic_book_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `comic_books`
--
ALTER TABLE `comic_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `rentals`
--
ALTER TABLE `rentals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `rental_items`
--
ALTER TABLE `rental_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ràng buộc đối với các bảng kết xuất
--

--
-- Ràng buộc cho bảng `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `fk_rentals_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ràng buộc cho bảng `rental_items`
--
ALTER TABLE `rental_items`
  ADD CONSTRAINT `fk_items_book` FOREIGN KEY (`comic_book_id`) REFERENCES `comic_books` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_items_rental` FOREIGN KEY (`rental_id`) REFERENCES `rentals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
