using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ComicSys.Api.Data;
using ComicSys.Api.Models;

namespace ComicSys.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CustomersController : ControllerBase
{
    private readonly AppDb _db;
    public CustomersController(AppDb db) { _db = db; }

    [HttpGet]
    public async Task<IActionResult> GetAllLite() =>
        Ok(await _db.Customers
            .OrderBy(x=>x.FullName)
            .Select(x => new { x.Id, x.FullName })
            .ToListAsync());

    [HttpPost]
    public async Task<IActionResult> Register(Customer input)
    {
        _db.Customers.Add(input);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetAllLite), new { id = input.Id }, input);
    }
}
