using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ComicSys.Api.Data;
using ComicSys.Api.Dtos;

namespace ComicSys.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ReportsController : ControllerBase
{
    private readonly AppDb _db;
    public ReportsController(AppDb db) { _db = db; }

    [HttpGet("rents")]
    public async Task<IActionResult> Rents([FromQuery] DateTime start, [FromQuery] DateTime end)
    {
        var q =
            from r in _db.Rentals.Include(x=>x.Items)
            join c in _db.Customers on r.CustomerId equals c.Id
            from it in r.Items
            join b in _db.ComicBooks on it.ComicBookId equals b.Id
            where r.RentalDate >= start && r.RentalDate <= end
            orderby r.RentalDate
            select new RentReportRow{
                BookName = b.Name,
                RentalDate = r.RentalDate,
                ReturnDate = r.ReturnDate,
                CustomerName = c.FullName,
                Quantity = it.Quantity
            };

        var rows = await q.ToListAsync();
        return Ok(rows);
    }
}
