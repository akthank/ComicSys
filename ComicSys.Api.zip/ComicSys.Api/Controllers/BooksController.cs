using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ComicSys.Api.Data;
using ComicSys.Api.Models;

namespace ComicSys.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BooksController : ControllerBase
{
    private readonly AppDb _db;
    public BooksController(AppDb db) { _db = db; }

    [HttpGet]
    public async Task<IActionResult> GetAll() =>
        Ok(await _db.ComicBooks.OrderBy(x=>x.Id).ToListAsync());

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var b = await _db.ComicBooks.FindAsync(id);
        return b is null ? NotFound() : Ok(b);
    }

    [HttpPost]
    public async Task<IActionResult> Create(ComicBook input)
    {
        _db.ComicBooks.Add(input);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = input.Id }, input);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, ComicBook input)
    {
        var b = await _db.ComicBooks.FindAsync(id);
        if (b is null) return NotFound();
        b.Name = input.Name; b.Author = input.Author;
        b.PricePerDay = input.PricePerDay; b.QuantityInStock = input.QuantityInStock;
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var b = await _db.ComicBooks.FindAsync(id);
        if (b is null) return NotFound();
        _db.ComicBooks.Remove(b);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
