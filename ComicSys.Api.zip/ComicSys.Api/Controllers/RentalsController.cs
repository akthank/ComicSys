using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ComicSys.Api.Data;
using ComicSys.Api.Models;
using ComicSys.Api.Dtos;

namespace ComicSys.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RentalsController : ControllerBase
{
    private readonly AppDb _db;
    public RentalsController(AppDb db) { _db = db; }

    [HttpPost]
    public async Task<IActionResult> Create(RentalCreateDto dto)
    {
        var customer = await _db.Customers.FindAsync(dto.CustomerId);
        if (customer is null) return BadRequest("Customer not found");

        var bookIds = dto.Items.Select(i=>i.ComicBookId).Distinct().ToList();
        var books = await _db.ComicBooks.Where(b=>bookIds.Contains(b.Id)).ToListAsync();
        foreach(var it in dto.Items)
        {
            var b = books.FirstOrDefault(x=>x.Id==it.ComicBookId);
            if (b is null) return BadRequest($"Book {it.ComicBookId} not found");
            if (b.QuantityInStock < it.Quantity) return BadRequest($"Not enough stock for {b.Name}");
            b.QuantityInStock -= it.Quantity;
        }

        var rental = new Rental {
            CustomerId = dto.CustomerId,
            RentalDate = dto.RentalDate,
            ReturnDate = dto.ReturnDate,
            Items = dto.Items.Select(i => new RentalItem{
                ComicBookId = i.ComicBookId,
                Quantity = i.Quantity,
                PricePerDay = i.PricePerDay
            }).ToList()
        };
        _db.Rentals.Add(rental);
        await _db.SaveChangesAsync();

        return Ok(new { rental.Id });
    }
}
