namespace ComicSys.Api.Dtos;

public class RentalCreateDto
{
    public int CustomerId { get; set; }
    public DateTime RentalDate { get; set; }
    public DateTime ReturnDate { get; set; }
    public List<RentalItemCreateDto> Items { get; set; } = new();
}

public class RentalItemCreateDto
{
    public int ComicBookId { get; set; }
    public int Quantity { get; set; }
    public decimal PricePerDay { get; set; }
}

public class RentReportRow
{
    public string BookName { get; set; } = "";
    public DateTime RentalDate { get; set; }
    public DateTime ReturnDate { get; set; }
    public string CustomerName { get; set; } = "";
    public int Quantity { get; set; }
}
