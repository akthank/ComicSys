namespace ComicSys.Api.Models;

public class ComicBook
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string? Author { get; set; }
    public decimal PricePerDay { get; set; }
    public int QuantityInStock { get; set; }

    public ICollection<RentalItem> RentalItems { get; set; } = new List<RentalItem>();
}
