using ComicSys.Api.Models;

namespace ComicSys.Api.Data;

public static class DbSeeder
{
    public static void Seed(AppDb db)
    {
        if (!db.ComicBooks.Any())
        {
            db.ComicBooks.AddRange(
                new ComicBook { Name = "One Piece 1", Author = "Oda",        PricePerDay = 2m,   QuantityInStock = 10 },
                new ComicBook { Name = "Naruto 1",    Author = "Kishimoto",  PricePerDay = 1.5m, QuantityInStock = 8  },
                new ComicBook { Name = "Doraemon 1",  Author = "Fujiko F.",  PricePerDay = 1.2m, QuantityInStock = 12 }
            );
        }

        if (!db.Customers.Any())
        {
            db.Customers.AddRange(
                new Customer { FullName = "Nguyen Van A", Phone = "090000001", RegisterDate = DateTime.UtcNow.AddDays(-5) },
                new Customer { FullName = "Tran Thi B",   Phone = "090000002", RegisterDate = DateTime.UtcNow }
            );
        }

        db.SaveChanges();
    }
}
