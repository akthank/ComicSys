using ComicSys.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace ComicSys.Api.Data;

public class AppDb : DbContext
{
    public AppDb(DbContextOptions<AppDb> opt) : base(opt) { }

    public DbSet<ComicBook>   ComicBooks   => Set<ComicBook>();
    public DbSet<Customer>    Customers    => Set<Customer>();
    public DbSet<Rental>      Rentals      => Set<Rental>();
    public DbSet<RentalItem>  RentalItems  => Set<RentalItem>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        // ===== ComicBook -> comic_books =====
        b.Entity<ComicBook>(e =>
        {
            e.ToTable("comic_books");
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.Name).HasColumnName("name");
            e.Property(x => x.Author).HasColumnName("author");
            e.Property(x => x.PricePerDay).HasColumnName("price_per_day").HasPrecision(10, 2);
            e.Property(x => x.QuantityInStock).HasColumnName("quantity_in_stock");
        });

        // ===== Customer -> customers =====
        b.Entity<Customer>(e =>
        {
            e.ToTable("customers");
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.FullName).HasColumnName("full_name");
            e.Property(x => x.Phone).HasColumnName("phone");
            e.Property(x => x.RegisterDate).HasColumnName("register_date");
        });

        // ===== Rental -> rentals =====
        b.Entity<Rental>(e =>
        {
            e.ToTable("rentals");
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.CustomerId).HasColumnName("customer_id");
            e.Property(x => x.RentalDate).HasColumnName("rental_date");
            e.Property(x => x.ReturnDate).HasColumnName("return_date");

            e.HasOne(x => x.Customer)
                .WithMany(c => c.Rentals)
                .HasForeignKey(x => x.CustomerId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        // ===== RentalItem -> rental_items =====
        b.Entity<RentalItem>(e =>
        {
            e.ToTable("rental_items");
            e.Property(x => x.Id).HasColumnName("id");
            e.Property(x => x.RentalId).HasColumnName("rental_id");
            e.Property(x => x.ComicBookId).HasColumnName("comic_book_id");
            e.Property(x => x.Quantity).HasColumnName("quantity");
            e.Property(x => x.PricePerDay).HasColumnName("price_per_day").HasPrecision(10, 2);

            e.HasOne(x => x.Rental)
                .WithMany(r => r.Items)
                .HasForeignKey(x => x.RentalId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.ComicBook)
                .WithMany(bk => bk.RentalItems)
                .HasForeignKey(x => x.ComicBookId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        base.OnModelCreating(b);
    }
}
