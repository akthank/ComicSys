using ComicSys.Api.Data;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// DbContext với MySQL 5.7
builder.Services.AddDbContext<AppDb>(opt =>
{
    var cs = builder.Configuration.GetConnectionString("Default");
    var serverVersion = ServerVersion.AutoDetect(cs); // hoạt động tốt với 5.7
    opt.UseMySql(cs, serverVersion, m => m.DisableBackslashEscaping());
});

// CORS cho Vite FE
builder.Services.AddCors(opt =>
{
    opt.AddPolicy("allow-fe", p =>
        p.WithOrigins("http://localhost:5173")
         .AllowAnyHeader()
         .AllowAnyMethod());
});

var app = builder.Build();

// Khởi tạo DB (demo: EnsureCreated). Sản xuất: dùng Migrations.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDb>();
    // db.Database.EnsureCreated();
    DbSeeder.Seed(db);
}

app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();
app.UseCors("allow-fe");
app.MapControllers();

app.Run();
